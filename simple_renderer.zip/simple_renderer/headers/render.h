#pragma once

#include "scene.h"

struct Integrator {
    Integrator(Scene& scene);

    long long render(int x,int val);

    Scene scene;
    Texture outputImage;
};
