#include "render.h"

Integrator::Integrator(Scene &scene)
{
    this->scene = scene;
    this->outputImage.allocate(TextureType::UNSIGNED_INTEGER_ALPHA, this->scene.imageResolution);
}
// uniform hemisphere sampling
Vector3f sample_upper_hemisphere_uniform()
{
    float r1 = next_float();
    float r2 = next_float();
    float theta = acos(r1);
    float phi = 2.0f * M_PI * r2;
    float x = sin(theta) * cos(phi);
    float y = sin(theta) * sin(phi);
    float z = cos(theta);
    return Vector3f(x, y, z);
}

// cosine-weighted hemisphere sampling
Vector3f sample_upper_hemisphere_cosine_weighted()
{
    float r1 = next_float();
    float r2 = next_float();
    float theta = acos((1 - 2 * r1) / 2);
    float phi = 2.0f * M_PI * r2;
    float x = sin(theta) * cos(phi);
    float y = sin(theta) * sin(phi);
    float z = cos(theta);
    return Vector3f(x, y, z);
}

long long Integrator::render(int spp, int val)
{
    auto startTime = std::chrono::high_resolution_clock::now();
    for (int x = 0; x < this->scene.imageResolution.x; x++)
    {        
        for (int y = 0; y < this->scene.imageResolution.y; y++)
        {
            Vector3f result(0.f, 0.f, 0.f);
            for (int i = 0; i < spp; i++)
            {
                Ray camera_ray = this->scene.camera.generateSPP_Ray(x, y);
                Interaction intersection = this->scene.rayIntersect(camera_ray);

                if (intersection.didIntersect) {

                    Vector3f shading_point = intersection.p + 1e-3f * intersection.n;
                    Vector3f outgoing_direction_local;
                    Vector3f outgoing_direction_world;
                    
                    if(val==2)
                    {                      

                        int lightIdx = rand() % this->scene.lights.size();
                        Light& light = this->scene.lights[lightIdx];

                        Vector3f radiance;
                        LightSample ls;
                        std::tie(radiance, ls) = light.sample(&intersection);

                        outgoing_direction_world=ls.wo;
                        outgoing_direction_local=intersection.toLocal(outgoing_direction_world);

                        Ray shadowRay(shading_point, outgoing_direction_world);

                        Interaction siShadow = this->scene.rayIntersect(shadowRay);
                        Interaction si_light = this->scene.rayEmitterIntersect(shadowRay);
                        
                        float area = 4*(light.getVx()*light.getVy());

                        
                        if ((!siShadow.didIntersect || siShadow.t > ls.d)&& si_light.didIntersect) {
                            result +=intersection.bsdf->eval(&intersection, outgoing_direction_local)*radiance * std::abs(Dot(intersection.n,outgoing_direction_world)) * area*(-1)*(Dot(Normalize(light.getNormal()),Normalize(ls.p-intersection.p)))/((ls.p-intersection.p).LengthSquared());   
                        }
                        
                    }
                    else 
                    {   
                        Vector3f monte_carlo(0.f,0.f,0.f);
                        

                        if (val == 0)
                        {
                            outgoing_direction_local = sample_upper_hemisphere_uniform();
                        }
                        else if(val==1)
                        {
                            outgoing_direction_local = sample_upper_hemisphere_cosine_weighted();
                        }

                        outgoing_direction_world = intersection.toWorld(outgoing_direction_local);
                        Ray shadowRay(intersection.p + 1e-3f * intersection.n, outgoing_direction_world);

                        Interaction siShadow = this->scene.rayIntersect(shadowRay);
                        Interaction si_light = this->scene.rayEmitterIntersect(shadowRay);

                        Vector3f radiance = si_light.emissiveColor;

                        if ((!siShadow.didIntersect || siShadow.t > si_light.t)&&si_light.didIntersect) {
                            if(val==0)
                            {
                                monte_carlo +=(2.0f)*(M_PI)*radiance * intersection.bsdf->eval(&intersection, outgoing_direction_local) * std::abs(Dot(intersection.n, outgoing_direction_world));
                            }
                            else if(val==1)
                            {
                                monte_carlo +=(M_PI)*radiance * intersection.bsdf->eval(&intersection, outgoing_direction_local);
                            }
                        }
                        result += monte_carlo;      
                    } 
                } 
                // if(i%100==0)
                // {
                //     std::cout<<"spp:"<<i<<std::endl;
                // }              

            }
            if(val==2){result*=this->scene.lights.size();}
            
            
            Ray CameraRay = this->scene.camera.generateRay(x,y);
            Interaction si_ = this->scene.rayEmitterIntersect(CameraRay);
            result /= spp;
            result+=si_.emissiveColor;
            this->outputImage.writePixelColor(result, x, y);
        }
    }
    auto finishTime = std::chrono::high_resolution_clock::now();

    return std::chrono::duration_cast<std::chrono::microseconds>(finishTime - startTime).count();
}


                
int main(int argc, char **argv)
{
    if (argc != 5)
    {
        std::cout << argc << std::endl;
        std::cerr << "Usage: ./render <scene_config> <out_path> <num_samples> <sampling_strategy>";
        return 1;
    }
    Scene scene(argv[1]);

    Integrator rayTracer(scene);
    int spp = atoi(argv[3]);
    auto renderTime = rayTracer.render(spp, atoi(argv[4]));

    std::cout << "Render Time: " << std::to_string(renderTime / 1000.f) << " ms" << std::endl;
    rayTracer.outputImage.save(argv[2]);

    return 0;
}
