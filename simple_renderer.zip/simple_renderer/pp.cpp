for (int x = 0; x < this->scene.imageResolution.x; x++) {
    for (int y = 0; y < this->scene.imageResolution.y; y++) {
        Vector3f result(0, 0, 0);
        for (int s = 0; s < spp; s++) {
            float offsetX = next_float();
            float offsetY = next_float();

            Ray cameraRay = this->scene.camera.generateRay(x + offsetX, y + offsetY);
            Interaction si = this->scene.rayIntersect(cameraRay);

            if (si.didIntersect) {
                Vector3f radiance;
                LightSample ls;
                for (Light &light : this->scene.lights) {
                    std::tie(radiance, ls) = light.sample(&si);

                    Ray shadowRay(si.p + 1e-3f * si.n, ls.wo);
                    Interaction siShadow = this->scene.rayEmitterIntersect(shadowRay); // Use rayEmitterIntersect

                    if (!siShadow.didIntersect || siShadow.t > ls.d) {
                        result += si.bsdf->eval(&si, si.toLocal(ls.wo))  * radiance * std::abs(Dot(si.n, ls.wo));
                    }
                }
            }
        }
        result /= spp;
        this->outputImage.writePixelColor(result, x, y);
    }
}